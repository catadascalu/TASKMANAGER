#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>

using namespace std;

class Task
{
private:
	std::string description;
	std::string status;
	int ProgrammerID;
public:
	Task() {}
	Task(string d, int i) :description(d), status("open"), ProgrammerID(i) {}
	Task(string d, string s, int i) : description(d), status(s), ProgrammerID(i) {}
	~Task() {}

	string getDescription() const { return this->description; }
	string getStatus() const { return this->status; }
	int getId() const { return this->ProgrammerID; }

	void setStatus(std::string stat) { this->status = stat; }
	void setId(int ID) { this->ProgrammerID = ID; }

	friend istream& operator>>(std::istream& is, Task& t)
	{
		std::string line;
		getline(is, line);
		std::stringstream ss(line);
		std::vector<string> temp;
		std::string attribute;
		while (getline(ss, attribute, ','))
		{
			temp.push_back(attribute);
		}

		if (temp.size() != 3)
			return is;

		t.description = temp.at(0);
		t.status = temp.at(1);
		t.ProgrammerID = std::stoi(temp.at(2));

		return is;
	}

	friend ostream& operator<<(std::ostream& os, const Task& t)
	{
		os << t.description << "," << t.status << "," << to_string(t.ProgrammerID) << "\n";
		return os;
	}
};