#include "TASKMANAGER.h"

TASKMANAGER::TASKMANAGER(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
